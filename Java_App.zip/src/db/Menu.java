package db;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.JTextArea;

public class Menu {

	private JFrame frame;
	private JLabel lblmoney1;
	private JTextArea textArea;
	
    private int EspressoCount = 0; // 에스프레소 수량을 저장할 변수
    private int CafeLatteCount = 0; // 카페라떼 수량을 저장할 변수
    private int HotChocolateCount = 0; // 핫초코 수량을 저장할 변수
    private int CoffeeCount = 0; // 아메리카노 수량을 저장할 변수
    private int	BubbleTeaCount = 0; // 버블티 수량을 저장할 변수
    private int	CokeCount = 0; // 탄산음로 수량을 저장할 변수
    private int	SandwichCount = 0; // 샌드위치 수량을 저장할 변수
    private int	CakeCount = 0; // 프리미엄 케이크 수량을 저장할 변수
    
    
 // 각 메뉴의 가격을 저장할 변수
    private final int ESPRESSO_PRICE = 4000;
    private final int CAFE_LATTE_PRICE = 6000;
    private final int HOT_CHOCOLATE_PRICE = 4500;
    private final int COFFEE_PRICE = 1500;
    private final int BUBBLE_TEA_PRICE = 6500;
    private final int COKE_PRICE = 2000;
    private final int SANDWICH_PRICE = 7500;
    private final int CAKE_PRICE = 8000;

    // 총 주문 수량을 계산하는 메서드
    private int calculateTotalCount() {
        return EspressoCount + CafeLatteCount + HotChocolateCount + CoffeeCount + 
               BubbleTeaCount + CokeCount + SandwichCount + CakeCount;
    }
    
    
    // 총 가격을 계산하는 메서드
    private int calculateTotalPrice(boolean[] isDiscounted) {
    	int totalPrice =  (EspressoCount * ESPRESSO_PRICE) +
               (CafeLatteCount * CAFE_LATTE_PRICE) +
               (HotChocolateCount * HOT_CHOCOLATE_PRICE) +
               (CoffeeCount * COFFEE_PRICE) +
               (BubbleTeaCount * BUBBLE_TEA_PRICE) +
               (CokeCount * COKE_PRICE) +
               (SandwichCount * SANDWICH_PRICE) +
               (CakeCount * CAKE_PRICE);
        
     // 3개 이상 주문 시 10% 할인
        int totalCount = calculateTotalCount();

        // 3개 이상 주문 시 10% 할인
        if (totalCount >= 3) {
        	totalPrice *= 0.9;
            isDiscounted[0] = true;  // 할인이 적용되었음을 표시
        } else {
            isDiscounted[0] = false; // 할인이 적용되지 않았음을 표시
        }
        return totalPrice;
    }
    
    private void updateTextArea(JTextArea textArea, String menuItem, int count) {  // 기존 텍스트에서 불필요한 공백을 제거
        String text = textArea.getText();  // 텍스트를 줄 단위로 분할
        String[] lines = text.split("\n");
        StringBuilder updatedText = new StringBuilder();

        boolean updated = false;
        for (String line : lines) { // 기존 메뉴 항목을 찾으면 업데이트된 수량으로 변경
            if (line.startsWith(menuItem)) {
                updatedText.append(menuItem).append(" - x").append(count).append("\n");
                updated = true;
            } else {  // 기존 항목을 그대로 유지
                updatedText.append(line).append("\n"); // 기존 텍스트가 있을 경우 줄바꿈을 추가
            }
        }

        if (!updated) { // 메뉴 항목이 없으면 새로 추가
            updatedText.append(menuItem).append(" - x").append(count).append("\n");
        }

        textArea.setText(updatedText.toString().trim()); // trim 양쪽 공백 지우기, 불필요한 공백 제거
    }
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menu window = new Menu();
					window.frame.setLocation(700, 40);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Menu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setTitle("The맛있는 카페 메뉴");
		frame.setBounds(100, 100, 618, 978);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	    frame.setResizable(false); // 크기 조정을 불가능하게 설정
			
		BackgroundPanel backgroundPanel = new BackgroundPanel("/images/Menubackground.jpeg");
		frame.setContentPane(backgroundPanel);
		backgroundPanel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(71, 714, 313, 152);
		backgroundPanel.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("한컴 말랑말랑 Regular", Font.BOLD, 16));
		scrollPane.setViewportView(textArea);
		
		JLabel lblSale = new JLabel("");
		lblSale.setIcon(new ImageIcon(Menu.class.getResource("/images/Sale.jpg")));
		lblSale.setBounds(78, 326, 41, 38);
		frame.getContentPane().add(lblSale);
		
		JLabel lblCafeLogo = new JLabel("");
		lblCafeLogo.setIcon(new ImageIcon(Menu.class.getResource("/images/Cafe_logo.png")));
		lblCafeLogo.setBounds(32, 10, 95, 100);
		frame.getContentPane().add(lblCafeLogo);
		
		JLabel lblCafeMenu = new JLabel("Cafe Menu");
		lblCafeMenu.setForeground(new Color(17, 132, 4));
		lblCafeMenu.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 16));
		lblCafeMenu.setBounds(32, 109, 95, 26);
		frame.getContentPane().add(lblCafeMenu);
		
		JLabel lblHot = new JLabel("hot\r\n");
		lblHot.setForeground(new Color(255, 128, 128));
		lblHot.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lblHot.setBounds(32, 145, 32, 26);
		frame.getContentPane().add(lblHot);
		
		JLabel lblCold = new JLabel("Cold");
		lblCold.setForeground(new Color(128, 128, 255));
		lblCold.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lblCold.setBounds(32, 296, 41, 26);
		frame.getContentPane().add(lblCold);
		
		JLabel imgEspresso = new JLabel("");
		imgEspresso.setIcon(new ImageIcon(Menu.class.getResource("/images/HotEspresso.jpg")));
		imgEspresso.setBounds(92, 144, 123, 126);
		frame.getContentPane().add(imgEspresso);
		
		JLabel imgCafeLatte = new JLabel("");
		imgCafeLatte.setIcon(new ImageIcon(Menu.class.getResource("/images/HotLatte.jpg")));
		imgCafeLatte.setBounds(241, 145, 123, 126);
		frame.getContentPane().add(imgCafeLatte);
		
		JLabel imgHotChocolate = new JLabel("");
		imgHotChocolate.setIcon(new ImageIcon(Menu.class.getResource("/images/HotChocolate.jpg")));
		imgHotChocolate.setBounds(393, 145, 123, 126);
		frame.getContentPane().add(imgHotChocolate);
		
		JLabel imgCoffee = new JLabel("");
		imgCoffee.setIcon(new ImageIcon(Menu.class.getResource("/images/ColdCoffee.jpg")));
		imgCoffee.setBounds(92, 337, 123, 126);
		frame.getContentPane().add(imgCoffee);
		
		JLabel imgBubbleTea = new JLabel("");
		imgBubbleTea.setIcon(new ImageIcon(Menu.class.getResource("/images/ColdBubbleTea.jpg")));
		imgBubbleTea.setBounds(241, 337, 123, 126);
		frame.getContentPane().add(imgBubbleTea);
		
		JLabel imgCoke = new JLabel("");
		imgCoke.setIcon(new ImageIcon(Menu.class.getResource("/images/ColdCoke.jpg")));
		imgCoke.setBounds(393, 337, 123, 126);
		frame.getContentPane().add(imgCoke);
		
		lblmoney1 = new JLabel("\\4.0");
		lblmoney1.setFont(new Font("나눔고딕", Font.PLAIN, 13));
		lblmoney1.setBounds(185, 275, 42, 38);
		frame.getContentPane().add(lblmoney1);
		
		JLabel lblmoney2 = new JLabel("\\6.0");
		lblmoney2.setFont(new Font("나눔고딕", Font.PLAIN, 13));
		lblmoney2.setBounds(336, 288, 41, 15);
		frame.getContentPane().add(lblmoney2);
		
		JLabel lblmoney3 = new JLabel("\\4.5");
		lblmoney3.setFont(new Font("나눔고딕", Font.PLAIN, 13));
		lblmoney3.setBounds(489, 287, 41, 15);
		frame.getContentPane().add(lblmoney3);
		
		JLabel lblmoney4 = new JLabel("\\1.5");
		lblmoney4.setFont(new Font("나눔고딕", Font.PLAIN, 13));
		lblmoney4.setBounds(185, 484, 41, 15);
		frame.getContentPane().add(lblmoney4);
		
		JLabel lblmoney5 = new JLabel("\\6.5");
		lblmoney5.setFont(new Font("나눔고딕", Font.PLAIN, 13));
		lblmoney5.setBounds(336, 484, 41, 15);
		frame.getContentPane().add(lblmoney5);
		
		JLabel lblmoney6 = new JLabel("\\2.0");
		lblmoney6.setFont(new Font("나눔고딕", Font.PLAIN, 13));
		lblmoney6.setBounds(489, 484, 41, 15);
		frame.getContentPane().add(lblmoney6);
		
		JLabel lblFood = new JLabel("food");
		lblFood.setForeground(new Color(128, 0, 0));
		lblFood.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lblFood.setBounds(32, 513, 52, 26);
		frame.getContentPane().add(lblFood);
		
		JLabel lblNewLabel_2_2_2 = new JLabel("");
		lblNewLabel_2_2_2.setIcon(new ImageIcon(Menu.class.getResource("/images/Sandwich.jpg")));
		lblNewLabel_2_2_2.setBounds(92, 522, 150, 126);
		frame.getContentPane().add(lblNewLabel_2_2_2);
		
		JLabel lblDessert = new JLabel("dessert");
		lblDessert.setForeground(new Color(255, 128, 192));
		lblDessert.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lblDessert.setBounds(287, 513, 81, 26);
		frame.getContentPane().add(lblDessert);
		
		JLabel lblNewLabel_2_2_2_1 = new JLabel("");
		lblNewLabel_2_2_2_1.setIcon(new ImageIcon(Menu.class.getResource("/images/Cake.jpg")));
		lblNewLabel_2_2_2_1.setBounds(366, 522, 150, 126);
		frame.getContentPane().add(lblNewLabel_2_2_2_1);
		
		JLabel lblmoney7 = new JLabel("\\7.5");
		lblmoney7.setFont(new Font("나눔고딕", Font.PLAIN, 13));
		lblmoney7.setBounds(201, 667, 41, 15);
		frame.getContentPane().add(lblmoney7);
		
		JLabel lblmoney8 = new JLabel("\\8.0");
		lblmoney8.setFont(new Font("나눔고딕", Font.PLAIN, 13));
		lblmoney8.setBounds(489, 667, 41, 15);
		frame.getContentPane().add(lblmoney8);
		
		JLabel lblNewLabel_4 = new JLabel("♣The맛있는 카페 공지\r\n♣");
		lblNewLabel_4.setForeground(new Color(17, 132, 4));
		lblNewLabel_4.setFont(new Font("한컴 말랑말랑 Regular", Font.BOLD, 16));
		lblNewLabel_4.setBounds(239, 10, 206, 26);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_4_1 = new JLabel("- 마시는 커피나 음료는 뜨겁게 차갑게 다 가능합니다. ");
		lblNewLabel_4_1.setFont(new Font("굴림", Font.BOLD, 12));
		lblNewLabel_4_1.setBounds(227, 35, 313, 26);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5 = new JLabel("변경시, 카운터에서 말씀해주세요.");
		lblNewLabel_5.setFont(new Font("굴림", Font.PLAIN, 12));
		lblNewLabel_5.setForeground(new Color(255, 0, 0));
		lblNewLabel_5.setBounds(241, 58, 264, 15);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("- 아메리카노 6.1~9.1까지 할인행사합니다^^");
		lblNewLabel_4_1_1.setFont(new Font("굴림", Font.BOLD, 12));
		lblNewLabel_4_1_1.setBounds(227, 71, 263, 26);
		frame.getContentPane().add(lblNewLabel_4_1_1);
		
		JLabel lblNewLabel_4_1_1_1 = new JLabel("- 3개이상 주문시 10% 할인합니다.");
		lblNewLabel_4_1_1_1.setFont(new Font("굴림", Font.BOLD, 12));
		lblNewLabel_4_1_1_1.setBounds(227, 93, 263, 26);
		frame.getContentPane().add(lblNewLabel_4_1_1_1);
		
		JLabel lblNewLabel_7 = new JLabel("");
		lblNewLabel_7.setBackground(new Color(240, 247, 240));
		lblNewLabel_7.setBounds(207, 10, 333, 112);
		lblNewLabel_7.setOpaque(true); // 배경이 투명하지 않도록 설정
		backgroundPanel.add(lblNewLabel_7);
		
		JButton btnCheck = new JButton("선택 완료");
		btnCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (textArea.getText().isEmpty()) {
		            // 텍스트가 비어있으면 메시지로 알림
		            JOptionPane.showMessageDialog(frame, "메뉴를 선택해주세요.", "알림", JOptionPane.INFORMATION_MESSAGE);
		        } else {
		        	 boolean[] isDiscounted = {false};
		             int totalPrice = calculateTotalPrice(isDiscounted);

		             String message = "총 가격은 " + totalPrice + "원 입니다.";
		             if (isDiscounted[0]) {
		                 message += " (10% 할인 적용)";
		             }
		             
		             JOptionPane.showMessageDialog(frame, message, "총 가격", JOptionPane.INFORMATION_MESSAGE);

		            // 메뉴가 선택되었으면 다음 프레임으로 넘어감
		            Number num = new Number();
		            num.getFrame().setVisible(true);
		            num.getFrame().setLocation(800, 300);
		            frame.setVisible(false); // 현재 Login 프레임 닫기
		        } // 현재 Login 프레임 닫기
			}
		});
		btnCheck.setBackground(new Color(216, 252, 197));
		btnCheck.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 15));
		btnCheck.setForeground(new Color(17, 132, 4));
		btnCheck.setBounds(78, 876, 206, 53);
		backgroundPanel.add(btnCheck);
		
		JButton btnBack = new JButton("취소");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login login_1 = new Login();
				login_1.getFrame().setLocation(800, 300);
				login_1.getFrame().setVisible(true);
				frame.setVisible(false); // 현재 Login 프레임 닫기
			}
		});
		btnBack.setBackground(new Color(206, 211, 255));
		btnBack.setForeground(new Color(0, 0, 160));
		btnBack.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 15));
		btnBack.setBounds(314, 876, 202, 53);
		backgroundPanel.add(btnBack);
		
		JLabel lblList = new JLabel("-List-");
		lblList.setForeground(new Color(17, 132, 4));
		lblList.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 16));
		lblList.setBounds(78, 689, 70, 26);
		backgroundPanel.add(lblList);
		
		JButton btnDelete = new JButton("삭제");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  try {
			            String str = textArea.getText();
			            if (str.isEmpty()) { // 텍스트가 비어있으면 메시지로 알림
			                JOptionPane.showMessageDialog(frame, "메뉴를 선택해주세요.", "알림", JOptionPane.WARNING_MESSAGE);
			                return;
			            }
			            // 텍스트를 줄 단위로 분할
			            String[] lines = str.split("\n");
			            if (lines.length > 0) {
			            	String lastLine = lines[lines.length - 1].trim();
			            	StringBuilder updatedText = new StringBuilder();
			                for (int i = 0; i < lines.length - 1; i++) {
			                    updatedText.append(lines[i]).append("\n");
			                }
			                // 결과를 textArea에 설정
			                textArea.setText(updatedText.toString());

			                // 각 메뉴의 수량을 업데이트 및 인덱스 0인상태에서 -1이 되는 것을 방지
			                if (lastLine.contains("에스프레소") && EspressoCount > 0) {
			                    EspressoCount--; // 에스프레소 수량 감소
			                    if (EspressoCount > 0) {
			                        updateTextArea(textArea, "에스프레소", EspressoCount);
			                    }
			                } else if (lastLine.contains("카페라떼") && CafeLatteCount > 0) {
			                    CafeLatteCount--; // 카페라떼 수량 감소
			                    if (CafeLatteCount > 0) {
			                        updateTextArea(textArea, "카페라떼", CafeLatteCount);
			                    }
			                } else if (lastLine.contains("핫초코") && HotChocolateCount > 0) {
			                    HotChocolateCount--; // 핫초코 수량 감소
			                    if (HotChocolateCount > 0) {
			                        updateTextArea(textArea, "핫초코", HotChocolateCount);
			                    }
			                } else if (lastLine.contains("아메리카노") && CoffeeCount > 0) {
			                    CoffeeCount--; // 아메리카노 수량 감소
			                    if (CoffeeCount > 0) {
			                        updateTextArea(textArea, "아메리카노", CoffeeCount);
			                    }
			                } else if (lastLine.contains("버블티") && BubbleTeaCount > 0) {
			                    BubbleTeaCount--; // 버블티 수량 감소
			                    if (BubbleTeaCount > 0) {
			                        updateTextArea(textArea, "버블티", BubbleTeaCount);
			                    }
			                } else if (lastLine.contains("탄산음료") && CokeCount > 0) {
			                    CokeCount--; // 탄산음료 수량 감소
			                    if (CokeCount > 0) {
			                        updateTextArea(textArea, "탄산음료", CokeCount);
			                    }
			                } else if (lastLine.contains("샌드위치") && SandwichCount > 0) {
			                    SandwichCount--; // 샌드위치 수량 감소
			                    if (SandwichCount > 0) {
			                        updateTextArea(textArea, "샌드위치", SandwichCount);
			                    }
			                } else if (lastLine.contains("프리미엄 케이크") && CakeCount > 0) {
			                    CakeCount--; // 프리미엄 케이크 수량 감소
			                    if (CakeCount > 0) {
			                        updateTextArea(textArea, "프리미엄 케이크", CakeCount);
			                    }
			                } else {
			                    JOptionPane.showMessageDialog(frame, "메뉴를 선택해주세요.", "알림", JOptionPane.INFORMATION_MESSAGE);
			                }
			            }
			        } 
			         catch (Exception ex) {
			        	// 예외 발생 시 메시지로 알림.
			            JOptionPane.showMessageDialog(frame, "예기치 않은 오류가 발생했습니다: " + ex.getMessage(), "오류", JOptionPane.ERROR_MESSAGE);
			        }
			    }
		});
		btnDelete.setForeground(new Color(128, 128, 128));
		btnDelete.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 15));
		btnDelete.setBackground(new Color(226, 226, 226));
		btnDelete.setBounds(396, 714, 123, 70);
		backgroundPanel.add(btnDelete);
		
		JButton btnAllDelete = new JButton("모두삭제");
		btnAllDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String str = textArea.getText();
			       if (str.isEmpty()) {
			            JOptionPane.showMessageDialog(frame, "메뉴를 선택해주세요.", "알림", JOptionPane.INFORMATION_MESSAGE);
			       } else {
			           textArea.setText(""); // 모든 텍스트 삭제
			           // 모든 수량 초기화
			           EspressoCount = 0;
			           CafeLatteCount = 0;
			           HotChocolateCount = 0;
			           CoffeeCount = 0;
			           BubbleTeaCount = 0;
			           CokeCount = 0;
			           SandwichCount = 0;
			           CakeCount = 0;
			       }
			   }
		});
		btnAllDelete.setForeground(new Color(255, 0, 0));
		btnAllDelete.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 15));
		btnAllDelete.setBackground(new Color(251, 189, 181));
		btnAllDelete.setBounds(396, 794, 123, 72);
		backgroundPanel.add(btnAllDelete);
		
		JButton btnEspresso = new JButton("에스프레소");
		btnEspresso.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EspressoCount++; // 수량 증가
				updateTextArea(textArea, "에스프레소", EspressoCount);
			}
		});
		btnEspresso.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 14));
		btnEspresso.setBounds(89, 275, 95, 36);
		backgroundPanel.add(btnEspresso);
		
		JButton btnCafeLatte = new JButton("카페라떼");
		btnCafeLatte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CafeLatteCount++; // 수량 증가
				updateTextArea(textArea, "카페라떼", CafeLatteCount);
			}
		});
		btnCafeLatte.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 14));
		btnCafeLatte.setBounds(241, 275, 95, 36);
		backgroundPanel.add(btnCafeLatte);
		
		JButton btnHotChocolate = new JButton("핫초코");
		btnHotChocolate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				HotChocolateCount++; // 수량 증가
				updateTextArea(textArea, "핫초코", HotChocolateCount);
			}
		});
		btnHotChocolate.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 14));
		btnHotChocolate.setBounds(393, 275, 95, 36);
		backgroundPanel.add(btnHotChocolate);
		
		JButton btnCoffee = new JButton("아메리카노");
		btnCoffee.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CoffeeCount++; // 수량 증가
				updateTextArea(textArea, "아메리카노", CoffeeCount);
			}
		});
		btnCoffee.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 13));
		btnCoffee.setBounds(91, 473, 93, 36);
		backgroundPanel.add(btnCoffee);
		
		JButton btnBubbleTea = new JButton("버블티");
		btnBubbleTea.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				BubbleTeaCount++; // 수량 증가
				updateTextArea(textArea, "버블티", BubbleTeaCount);
			}
			
		});
		btnBubbleTea.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 14));
		btnBubbleTea.setBounds(241, 473, 95, 36);
		backgroundPanel.add(btnBubbleTea);
		
		JButton btnCoke = new JButton("탄산음료");
		btnCoke.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CokeCount++; // 수량 증가
				updateTextArea(textArea, "탄산음료", CokeCount);
			}
		});
		btnCoke.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 14));
		btnCoke.setBounds(393, 472, 94, 36);
		backgroundPanel.add(btnCoke);
		
		JButton btnSandwich = new JButton("샌드위치");
		btnSandwich.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SandwichCount++; // 수량 증가
				updateTextArea(textArea, "샌드위치", SandwichCount);
			}
		});
		btnSandwich.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 14));
		btnSandwich.setBounds(92, 658, 105, 36);
		backgroundPanel.add(btnSandwich);
		
		JButton btnCake = new JButton("프리미엄 케이크");
		btnCake.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CakeCount++; // 수량 증가
				 updateTextArea(textArea, "프리미엄 케이크", CakeCount);
			}
		});
		btnCake.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 12));
		btnCake.setBounds(366, 658, 121, 36);
		backgroundPanel.add(btnCake);
		}

	public JFrame getFrame() {
		return frame;
	}
	
}

