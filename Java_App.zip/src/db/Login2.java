package db;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Window;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JPasswordField;

public class Login2 {

	private JFrame frame;
	private JTextField tfPW_CK;
	private JTextField tfNAME;
	private JTextField tfID;
	private Connection conn;
	private JPasswordField PW;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login2 login_2 = new Login2();
					login_2.frame.setLocation(800, 300);
					login_2.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login2() {
		initialize();
		conn = DB.init();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(190, 235, 180));
		frame.getContentPane().setFont(new Font("굴림", Font.BOLD, 16));
		frame.setTitle("회원가입");
		frame.setBounds(100, 100, 381, 297);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	    frame.setResizable(false); // 크기 조정을 불가능하게 설정
			
		BackgroundPanel backgroundPanel_2 = new BackgroundPanel("/images/Cafe Login.png");
		frame.setContentPane(backgroundPanel_2);
		backgroundPanel_2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setForeground(new Color(17, 132, 4));
		lblNewLabel.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lblNewLabel.setBounds(12, 45, 36, 26);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblPw = new JLabel("PW");
		lblPw.setForeground(new Color(17, 132, 4));
		lblPw.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 17));
		lblPw.setBounds(12, 81, 36, 22);
		frame.getContentPane().add(lblPw);
		
		tfPW_CK = new JTextField();
		tfPW_CK.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				 if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			            String password = new String(PW.getPassword());
			            String passwordConfirm = tfPW_CK.getText().trim(); // trim()은 문자열 앞뒤 공백제거
			            if (!password.equals(passwordConfirm)) {
			                JOptionPane.showMessageDialog(frame, "비밀번호가 일치하지 않습니다.", "입력 오류",
			                        JOptionPane.ERROR_MESSAGE);
			            } else {
			            	tfNAME.requestFocusInWindow(); // tfNAME로 이동해 비밀번호 입력하기
			            }
				 }
			}
		});
		tfPW_CK.setFont(new Font("굴림", Font.BOLD, 16));
		tfPW_CK.setColumns(10);
		tfPW_CK.setBounds(90, 122, 171, 27);
		frame.getContentPane().add(tfPW_CK);
		
		JButton btnNewButton = new JButton("회원가입 완료");
		btnNewButton.setForeground(new Color(17, 132, 4));
		btnNewButton.setBackground(new Color(216, 252, 197));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(tfID.getText().isEmpty() || PW.getPassword().length == 0 || tfPW_CK.getText().isEmpty() || tfNAME.getText().isEmpty()) {
					JOptionPane.showMessageDialog(frame, "모든 빈칸을 입력하세요.", "입력 오류", JOptionPane.ERROR_MESSAGE);
				} else { // 아니면 회원가입 하기
				try {
					String sql = "INSERT INTO people_info "
							+ "(ID, PW, userName) "
							+ "VALUES(?, ?, ?)";
					
					PreparedStatement pstmt = conn.prepareStatement(sql);
					
					pstmt.setString(1, tfID.getText());
					pstmt.setString(2, PW.getText());
					pstmt.setString(3, tfNAME.getText());
					
					pstmt.execute();
					
					JOptionPane.showMessageDialog(frame, "회원가입이 완료되었습니다.");
					
					pstmt.close();
					
					Login login_1 = new Login();
					login_1.getFrame().setLocation(800, 300);
					login_1.getFrame().setVisible(true);
					frame.setVisible(false); // 현재 Login 프레임 닫기
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		}
		});
		btnNewButton.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 15));
		btnNewButton.setBounds(12, 196, 161, 55);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblPW_1 = new JLabel("닉네임");
		lblPW_1.setForeground(new Color(17, 132, 4));
		lblPW_1.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lblPW_1.setBounds(12, 161, 57, 22);
		frame.getContentPane().add(lblPW_1);
		
		tfNAME = new JTextField();
		tfNAME.setFont(new Font("굴림", Font.BOLD, 16));
		tfNAME.setColumns(10);
		tfNAME.setBounds(90, 159, 171, 27);
		frame.getContentPane().add(tfNAME);
		
		JLabel lblPW_3 = new JLabel("PW 확인");
		lblPW_3.setForeground(new Color(17, 132, 4));
		lblPW_3.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lblPW_3.setBounds(12, 124, 71, 22);
		frame.getContentPane().add(lblPW_3);
		
		tfID = new JTextField();
		tfID.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER)
					PW.requestFocusInWindow(); // PW로 이동해 비밀번호 입력하기
			}
		});
		tfID.setFont(new Font("굴림", Font.BOLD, 16));
		tfID.setColumns(10);
		tfID.setBounds(90, 46, 171, 25);
		frame.getContentPane().add(tfID);
		
		JButton btnNewButton_1 = new JButton("중복 확인");
		btnNewButton_1.setForeground(new Color(17, 132, 4));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // 닉네임 중복 확인
				String username = tfNAME.getText().trim();
				
				 // 데이터베이스에서 닉네임 중복 확인
		        if (isUsernameExists(username)) {
		            JOptionPane.showMessageDialog(frame, "이미 사용 중인 닉네임입니다.", "중복 확인", JOptionPane.ERROR_MESSAGE);
		        } else {
		            JOptionPane.showMessageDialog(frame, "사용 가능한 닉네임입니다.", "중복 확인", JOptionPane.INFORMATION_MESSAGE);
		        }
			}
		});
		btnNewButton_1.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 11));
		btnNewButton_1.setBounds(270, 160, 83, 29);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("뒤로가기\r\n");
		btnNewButton_2.setForeground(new Color(0, 0, 160));
		btnNewButton_2.setBackground(new Color(206, 211, 255));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			Login login_1 = new Login();
			login_1.getFrame().setLocation(800, 300);
			login_1.getFrame().setVisible(true);
			frame.setVisible(false); // 현재 Login 프레임 닫기
			}
		});
		btnNewButton_2.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 15));
		btnNewButton_2.setBounds(185, 196, 168, 55);
		frame.getContentPane().add(btnNewButton_2);
		
		PW = new JPasswordField();
		PW.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER)
					tfPW_CK.requestFocusInWindow(); // tfPW_CK로 이동해 비밀번호 입력하기
			}
		});
		PW.setBounds(90, 81, 171, 26);
		frame.getContentPane().add(PW);
		
		JLabel lblNewLabel_1 = new JLabel("♣어서오세요♣");
		lblNewLabel_1.setForeground(new Color(17, 132, 4));
		lblNewLabel_1.setFont(new Font("한컴 말랑말랑 Regular", Font.BOLD, 16));
		lblNewLabel_1.setBounds(124, 7, 105, 29);
		frame.getContentPane().add(lblNewLabel_1);
	}
	
	public JFrame getFrame() {
		return frame;
	}
	
	private boolean isUsernameExists(String username) {
		try {
	        String sql = "SELECT COUNT(*) FROM people_info WHERE userName=?";
	        PreparedStatement pstmt = conn.prepareStatement(sql);
	        pstmt.setString(1, username); // ?자리에 주어진 닉네임 설정
	        ResultSet rs = pstmt.executeQuery(); // ResultSet 객체에 저장
	        
	        rs.next(); // ResultSet 객체에서 결과를 가져옴.
	        int count = rs.getInt(1); // 현재 행의 첫번째 값 가져옴.
	        
	        rs.close();
	        pstmt.close();
	        
	        return count > 0; // 중복되었을 때, true값 반환
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
}
