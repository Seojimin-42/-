package db;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import com.mysql.cj.protocol.Resultset;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Login {

	private JFrame frame;
	private JTextField tfID;
	private JPasswordField PW;
	private Connection conn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login login_1 = new Login();
					login_1.frame.setLocation(800, 300);
					login_1.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
		conn = DB.init();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(190, 235, 180));
		frame.setTitle("로그인 화면");
		frame.setBounds(100, 100, 390, 265);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
        frame.setResizable(false); // 크기 조정을 불가능하게 설정
		
	    BackgroundPanel backgroundPanel = new BackgroundPanel("/images/Cafe Login.png");
	    frame.setContentPane(backgroundPanel);
	    backgroundPanel.setLayout(null);
		
		JLabel lbl_ID = new JLabel(" ID");
		lbl_ID.setForeground(new Color(17, 132, 4));
		lbl_ID.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lbl_ID.setBounds(136, 56, 44, 31);
		frame.getContentPane().add(lbl_ID);
		
		JLabel lbl_PW = new JLabel("PW");
		lbl_PW.setForeground(new Color(17, 132, 4));
		lbl_PW.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 18));
		lbl_PW.setBounds(136, 97, 44, 31);
		frame.getContentPane().add(lbl_PW);
		
		tfID = new JTextField();
		tfID.setToolTipText("");
		tfID.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER)
					PW.requestFocusInWindow(); // PW로 이동해 비밀번호 입력하기
			}
		});
		tfID.setBounds(176, 57, 166, 29);
		frame.getContentPane().add(tfID);
		tfID.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("♣The맛있는 카페에 오신걸 환영합니다!♣");
		lblNewLabel_2.setForeground(new Color(17, 132, 4));
		lblNewLabel_2.setBackground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("한컴 말랑말랑 Regular", Font.BOLD, 15));
		lblNewLabel_2.setBounds(52, 10, 269, 25);
		frame.getContentPane().add(lblNewLabel_2);
		
		JButton btnLogin = new JButton("로그인");
		btnLogin.setForeground(new Color(17, 132, 4));
		btnLogin.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 14));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
		            String sql = "SELECT * FROM people_info WHERE ID=? AND PW=?";
		            PreparedStatement pstmt = conn.prepareStatement(sql);
		            
		            pstmt.setString(1, tfID.getText());
		            pstmt.setString(2, new String(PW.getPassword())); // 패스워드는 char[] 형태로 가져와야 합니다
		            ResultSet rs = pstmt.executeQuery();
		            
		            if(rs.next()) {
		            	String userName = rs.getString("userName"); // 오류 수정 userName
		            	
		                JOptionPane.showMessageDialog(frame, "환영합니다." + userName + "님!");
		                // 로그인 성공 후 필요한 작업 수행
		                
		                Menu menuWindow = new Menu();
		                menuWindow.getFrame().setLocation(700, 40);
		                menuWindow.getFrame().setVisible(true);
		                frame.setVisible(false); // 현재 Login 프레임 닫기
		                
		                
		            } else {
		                JOptionPane.showMessageDialog(frame, "아이디 또는 비밀번호를 확인해주세요.");
		            }
		            
		            rs.close();
		            pstmt.close();
		            
		            
		            
		            
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
			
		btnLogin.setBackground(new Color(216, 252, 197));
		btnLogin.setBounds(29, 154, 145, 43);
		frame.getContentPane().add(btnLogin);
		
		JButton btnJoin = new JButton("회원가입");
		btnJoin.setForeground(new Color(17, 132, 4));
		btnJoin.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 14));
		btnJoin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Login2 login_2 = new Login2();
				login_2.getFrame().setLocation(800, 300);
				login_2.getFrame().setVisible(true);
				
				frame.setVisible(false); // 현재 Login 프레임 닫기
			}
		});
		btnJoin.setBackground(new Color(255, 255, 255));
		btnJoin.setBounds(197, 154, 145, 43);
		frame.getContentPane().add(btnJoin);
		
		PW = new JPasswordField();
		PW.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ENTER)
					btnLogin.doClick();  // enter를 누르면 btnLogin 실행하기
			}
		});
		PW.setBounds(176, 97, 166, 32);
		frame.getContentPane().add(PW);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(Login.class.getResource("/images/Cafe_logo.png")));
		lblNewLabel_3.setBounds(29, 45, 95, 100);
		frame.getContentPane().add(lblNewLabel_3);
	}

	public JFrame getFrame() {
		return frame;
	}
	
}
