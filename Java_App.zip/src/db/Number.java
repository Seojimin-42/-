package db;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Number {

	private JFrame frame;
	private JTextField textField;
	private JTextField tfNum1;
	private JLabel lblNewLabel;
	private JButton btnNOTCK;
	private JButton btnC;
	private JButton btn_Num1;
	private JButton btn_Num2;
	private JButton btn_Num3;
	private JButton btn_Num4;
	private JButton btn_Num5;
	private JButton btn_Num6;
	private JButton btn_Num7;
	private JButton btn_Num8;
	private JButton btn_Num9;
	private JButton btn_Num0;
	private JButton btnCK;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Number window = new Number();
					window.frame.setVisible(true);
					window.frame.setLocation(800, 300);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Number() {
		initialize();
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(240, 247, 240));
		frame.setTitle("포인트 적립");
		frame.setBounds(100, 100, 375, 374);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setEditable(false);
		textField.setHorizontalAlignment(SwingConstants.CENTER);
		textField.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		textField.setText("010");
		textField.setBounds(12, 10, 72, 53);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		tfNum1 = new JTextField();
		tfNum1.setHorizontalAlignment(SwingConstants.CENTER);
		tfNum1.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		tfNum1.setColumns(10);
		tfNum1.setBounds(109, 10, 236, 53);
		frame.getContentPane().add(tfNum1);
		
		tfNum1.addKeyListener(new KeyAdapter() {
		    @Override
		    public void keyTyped(KeyEvent e) {
		        JTextField src = (JTextField) e.getSource();
		        
		        // 8자리 초과하는 경우 입력 차단
		        if (src.getText().length() >= 8) {
		            e.consume();
		        }
		    }
		});

		
		lblNewLabel = new JLabel("-");
		lblNewLabel.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 24));
		lblNewLabel.setBounds(88, 10, 13, 53);
		frame.getContentPane().add(lblNewLabel);
		
		btnNOTCK = new JButton("안함");
		btnNOTCK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(frame, "계산은 카운터에서 도와드리겠습니다. 감사합니다^^");
				frame.setVisible(false);
			}
		});
		btnNOTCK.setOpaque(true);
		btnNOTCK.setForeground(Color.BLACK);
		btnNOTCK.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 16));
		btnNOTCK.setBackground(new Color(227, 227, 227));
		btnNOTCK.setBounds(12, 205, 72, 118);
		frame.getContentPane().add(btnNOTCK);
		
		btnC = new JButton("C");
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String str = tfNum1.getText();
				tfNum1.setText(str.substring(0, str.length()-1));
			}
		});
		btnC.setOpaque(true);
		btnC.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btnC.setBackground(SystemColor.activeCaption);
		btnC.setBounds(273, 262, 72, 61);
		frame.getContentPane().add(btnC);
		
		btn_Num1 = new JButton("1");
		btn_Num1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "1");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num1.setOpaque(true);
		btn_Num1.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num1.setBackground(new Color(216, 252, 197));
		btn_Num1.setBounds(105, 73, 72, 53);
		frame.getContentPane().add(btn_Num1);
		
		btn_Num2 = new JButton("2");
		btn_Num2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "2");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num2.setOpaque(true);
		btn_Num2.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num2.setBackground(new Color(216, 252, 197));
		btn_Num2.setBounds(189, 73, 72, 53);
		frame.getContentPane().add(btn_Num2);
		
		btn_Num3 = new JButton("3");
		btn_Num3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "3");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num3.setOpaque(true);
		btn_Num3.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num3.setBackground(new Color(216, 252, 197));
		btn_Num3.setBounds(273, 73, 72, 53);
		frame.getContentPane().add(btn_Num3);
		
		btn_Num4 = new JButton("4");
		btn_Num4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "4");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num4.setOpaque(true);
		btn_Num4.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num4.setBackground(new Color(216, 252, 197));
		btn_Num4.setBounds(105, 136, 72, 53);
		frame.getContentPane().add(btn_Num4);
		
		btn_Num5 = new JButton("5");
		btn_Num5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "5");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num5.setOpaque(true);
		btn_Num5.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num5.setBackground(new Color(216, 252, 197));
		btn_Num5.setBounds(189, 136, 72, 53);
		frame.getContentPane().add(btn_Num5);
		
		btn_Num6 = new JButton("6");
		btn_Num6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "6");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num6.setOpaque(true);
		btn_Num6.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num6.setBackground(new Color(216, 252, 197));
		btn_Num6.setBounds(273, 136, 72, 53);
		frame.getContentPane().add(btn_Num6);
		
		btn_Num7 = new JButton("7");
		btn_Num7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "7");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num7.setOpaque(true);
		btn_Num7.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num7.setBackground(new Color(216, 252, 197));
		btn_Num7.setBounds(105, 199, 72, 53);
		frame.getContentPane().add(btn_Num7);
		
		btn_Num8 = new JButton("8");
		btn_Num8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "8");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num8.setOpaque(true);
		btn_Num8.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num8.setBackground(new Color(216, 252, 197));
		btn_Num8.setBounds(189, 199, 72, 53);
		frame.getContentPane().add(btn_Num8);
		
		btn_Num9 = new JButton("9");
		btn_Num9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "9");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num9.setOpaque(true);
		btn_Num9.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num9.setBackground(new Color(216, 252, 197));
		btn_Num9.setBounds(273, 199, 72, 53);
		frame.getContentPane().add(btn_Num9);
		
		btn_Num0 = new JButton("0");
		btn_Num0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tfNum1.getText().length() < 9) {
		            tfNum1.setText(tfNum1.getText() + "0");
		        }
				if (tfNum1.getText().length() == 4) {
			        tfNum1.setText(tfNum1.getText() + "-");
			    }
			}
		});
		btn_Num0.setOpaque(true);
		btn_Num0.setFont(new Font("한컴 말랑말랑 Bold", Font.PLAIN, 18));
		btn_Num0.setBackground(new Color(216, 252, 197));
		btn_Num0.setBounds(105, 262, 156, 61);
		frame.getContentPane().add(btn_Num0);
		
		btnCK = new JButton("확인\r\n");
		btnCK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String phoneNumber = tfNum1.getText().replace("-", "").trim();
				if (phoneNumber.length() < 8) {
		            JOptionPane.showMessageDialog(frame, "전화번호를 입력하세요.");
		        } else {
		            JOptionPane.showMessageDialog(frame, "포인트 적립이 완료되었습니다." + "\n계산은 카운터에서 도와드리겠습니다. 감사합니다^^");
		            frame.setVisible(false);
		        }
			}
		});
		btnCK.setForeground(new Color(255, 145, 125));
		btnCK.setOpaque(true);
		btnCK.setFont(new Font("한컴 말랑말랑 Bold", Font.BOLD, 16));
		btnCK.setBackground(new Color(255, 231, 227));
		btnCK.setBounds(12, 73, 72, 122);
		frame.getContentPane().add(btnCK);
		}

		public JFrame getFrame() {
			return frame;
		}
	}

